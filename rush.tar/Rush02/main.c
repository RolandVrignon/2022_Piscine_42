#include "utils.h"

int main(int ac, char **av)
{
    (void)ac;
    (void)av;

    if (ac != 2)
        return (0);

    t_dict *dict;
    t_dict *p_dict;
    char **tab;
    int size = 0;
    int i = 0;
    int power = 0;

    dict = create_list(ac);
    tab = triple_tab(av[1]);

    int j;
    j = -1;
    while (tab[j++])
        printf("Tab[%d] = %s\n", j, tab[j]);

    printf("\n\n\n");

    while (tab[size])
        size++;

    while (i < size)
    {
        print_number(tab[i], dict);
        power = ((size - 1) - i) * 3;
        if (power != 0)
        {
            char test[power + 2];

            int k = 0;
            while (power + 1 > 0)
            {
                if (k == 0)
                    test[0] = '1';
                else
                    test[k] = '0';
                k++;
                power--;
            }
            test[k] = '\0';

            p_dict = dict;
            while (ft_strcmp(test, p_dict->key) != 0 && p_dict->next != NULL)
                p_dict = p_dict->next;

            printf("/%s/", p_dict->value);
        }
        i++;
    }

    // char fifty[] = "50";
    // dict = go_to(dict, fifty);
    // printf("Key : %s\nValue : %s\nPrevious : %p || Current : %p || Next : %p\n\n", dict->key, dict->value, dict->previous, dict, dict->next);

    // char b[] = "100";
    // dict = go_to(dict, b);
    // printf("Key : %s\nValue : %s\nPrevious : %p || Current : %p || Next : %p\n\n", dict->key, dict->value, dict->previous, dict, dict->next);

    // char c[] = "30";
    // dict = go_to(dict, c);
    // printf("Key : %s\nValue : %s\nPrevious : %p || Current : %p || Next : %p\n\n", dict->key, dict->value, dict->previous, dict, dict->next);

    // free(tab);
}